displayed at font size 12 without antialiasing in Sublime Text
