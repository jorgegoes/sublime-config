Gallery image displayed at font size 12 with antialiasing off in Sublime Text
