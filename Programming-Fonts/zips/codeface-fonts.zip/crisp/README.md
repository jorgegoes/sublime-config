Gallery images rendered at font size 12 without antialiasing
